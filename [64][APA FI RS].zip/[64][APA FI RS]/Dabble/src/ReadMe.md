{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang1033{\fonttbl{\f0\fnil\fcharset0 Calibri;}}
{\*\generator Riched20 6.3.9600}\viewkind4\uc1 
\pard\sl240\slmult1\f0\fs22\lang9 Dabble \par
Version - 0.0.1\par
Date -21/12/2018\par
This is a first version of Dabble app that has following modules in fully functioning form:\par
LedBrightnessControl, Terminal, Gamepad, Pin State Monitor, Motor Control, Inputs, PhoneSensor.\par
Links  for example codes are added.\par
\par
Improvements needed:\par
Add more examples that explore use cases of each these modules.\par
Somehow if possible see how user can avoid writing Dabble.processInput()\par
Query command from device to app for getting current status of module.\par

\pard\sa200\sl240\slmult1\par
}
 